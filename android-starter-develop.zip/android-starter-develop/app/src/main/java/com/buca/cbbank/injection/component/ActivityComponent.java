package com.buca.cbbank.injection.component;

import dagger.Subcomponent;
import com.buca.cbbank.features.kpi.KpiActivity;
import com.buca.cbbank.features.main.MainActivity;
import com.buca.cbbank.injection.PerActivity;
import com.buca.cbbank.injection.module.ActivityModule;

@PerActivity
@Subcomponent(modules = ActivityModule.class)
public interface ActivityComponent {
    void inject(MainActivity mainActivity);
    void inject (KpiActivity kpiActivity);
}
