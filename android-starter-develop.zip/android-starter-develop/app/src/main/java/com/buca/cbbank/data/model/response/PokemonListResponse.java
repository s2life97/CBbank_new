package com.buca.cbbank.data.model.response;

import java.util.List;

public class PokemonListResponse {
    public List<NamedResource> results;
}
