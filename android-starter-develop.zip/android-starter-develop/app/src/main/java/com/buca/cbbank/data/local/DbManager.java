package com.buca.cbbank.data.local;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Created by shivam on 29/5/17.
 */

// To be implemented with Realm

@Singleton
public class DbManager {

    @Inject
    public DbManager() {
    }
}
