package com.buca.cbbank.features.kpi;

import com.buca.cbbank.features.base.MvpView;

public interface KpiView extends MvpView {
}
