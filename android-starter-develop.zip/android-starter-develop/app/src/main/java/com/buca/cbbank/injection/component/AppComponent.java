package com.buca.cbbank.injection.component;

import android.app.Application;
import android.content.Context;

import javax.inject.Singleton;

import dagger.Component;
import com.buca.cbbank.data.DataManager;
import com.buca.cbbank.injection.ApplicationContext;
import com.buca.cbbank.injection.module.AppModule;

@Singleton
@Component(modules = AppModule.class)
public interface AppComponent {

    @ApplicationContext
    Context context();

    Application application();

    DataManager apiManager();
}
