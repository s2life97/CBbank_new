package com.buca.cbbank;

/**
 * Created by shivam on 29/5/17.
 */
public interface Constants {

    String PREF_FILE_NAME = "mvpstarter_pref_file";
}
