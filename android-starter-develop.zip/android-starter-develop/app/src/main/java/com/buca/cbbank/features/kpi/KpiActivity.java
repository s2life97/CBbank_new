package com.buca.cbbank.features.kpi;

import android.os.Bundle;

import com.buca.cbbank.R;
import com.buca.cbbank.features.base.BaseActivity;
import com.buca.cbbank.injection.component.ActivityComponent;

import javax.inject.Inject;

import androidx.appcompat.app.AppCompatActivity;
import antonkozyriatskyi.circularprogressindicator.CircularProgressIndicator;
import butterknife.BindView;
import butterknife.ButterKnife;

public class KpiActivity extends BaseActivity implements KpiView {
    @Inject
    KpiPresent kpiPresent;
    @BindView(R.id.circular_progress)
    CircularProgressIndicator circularProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kpi);
        ButterKnife.bind(this);
        setupProgressBar();
    }

    private void setupProgressBar() {
        circularProgress.setMaxProgress(100);
        circularProgress.setCurrentProgress(50);
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_kpi;
    }

    @Override
    protected void inject(ActivityComponent activityComponent) {
        activityComponent.inject(this);
    }

    @Override
    protected void attachView() {
        kpiPresent.attachView(this);
    }

    @Override
    protected void detachPresenter() {
        kpiPresent.detachView();
    }
}
