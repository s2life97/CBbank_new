package com.buca.cbbank.data.model.response;

import java.util.List;

public class Pokemon {
    public String id;
    public String name;
    public Sprites sprites;
    public List<Statistic> stats;
}
