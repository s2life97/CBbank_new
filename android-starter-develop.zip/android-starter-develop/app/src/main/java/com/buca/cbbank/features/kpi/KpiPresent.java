package com.buca.cbbank.features.kpi;

import com.buca.cbbank.features.base.BasePresenter;

import javax.inject.Inject;

public class KpiPresent extends BasePresenter<KpiView> {
    @Inject
    public KpiPresent() {
    }
    @Override
    public void attachView(KpiView mvpView) {
        super.attachView(mvpView);
    }

    @Override
    public void detachView() {
        super.detachView();
    }
}
