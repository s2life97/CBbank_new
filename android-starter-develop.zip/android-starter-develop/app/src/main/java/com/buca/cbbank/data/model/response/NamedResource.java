package com.buca.cbbank.data.model.response;

public class NamedResource {
    public String name;
    public String url;
}
