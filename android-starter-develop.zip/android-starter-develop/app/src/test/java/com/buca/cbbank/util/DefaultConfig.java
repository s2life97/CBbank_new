package com.buca.cbbank.util;

public class DefaultConfig {
    //The api level that Roboelectric will use to run the unit tests
    public static final int EMULATE_SDK = 24;
}
