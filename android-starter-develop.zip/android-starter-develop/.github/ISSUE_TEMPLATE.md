<!-- Love android-starter? Please consider supporting our collective:
👉  https://opencollective.com/android-starter/donate -->